D3 US Map with Hover
====================

Basic US map using D3 and topojson.  Each state gets colored and neighbors should never be the same color.  Also has some mousein/mouseout functions for highlighting the state your cursor is over